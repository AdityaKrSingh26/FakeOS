import React from 'react'

const validator = () => {
  return (
    <div>validator</div>
  )
}

export default validator