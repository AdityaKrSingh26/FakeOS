const LandingPage = () => {
  return (
    <div>
      <h1>Welcome to my library</h1>
      <h2>Feel free to stay quiet ☕️</h2>
    </div>
  );
};

export default LandingPage;
