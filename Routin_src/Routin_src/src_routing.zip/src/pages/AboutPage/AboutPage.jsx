const AboutPage = () => {
  return (
    <div>
      <h2>This is a library</h2>
      <p>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Inventore,
        impedit accusamus. Dolores voluptatum temporibus corrupti ullam?
        Pariatur dolor nulla exercitationem harum nobis alias ullam aperiam
        cumque praesentium ratione, consequatur quidem? Lorem ipsum dolor sit
        amet consectetur adipisicing elit. Nisi minima quis facere illum,
        perferendis eaque fugiat. Illum vitae suscipit reiciendis earum debitis
        in iure dolorem. Deleniti consequatur ducimus voluptatum quis? Lorem,
        ipsum dolor sit amet consectetur adipisicing elit. Quisquam, dolores
        temporibus eius incidunt molestias inventore omnis numquam sequi eum
        eveniet! Totam ipsum delectus officiis. Sed id facilis provident
        deleniti alias? Lorem ipsum dolor sit amet consectetur adipisicing elit.
        Beatae molestias labore laudantium totam! Natus, cupiditate quibusdam
        corrupti enim magnam dolor, veritatis quisquam doloribus assumenda
        libero adipisci maxime, fugit distinctio quia?
      </p>
    </div>
  );
};

export default AboutPage;
