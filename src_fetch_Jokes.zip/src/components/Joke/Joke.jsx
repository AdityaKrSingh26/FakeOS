const Joke = ({ joke }) => {
  console.log("testing", joke);
  return (
    <>
      <h1>test{joke}</h1>
    </>
  );
};

export default Joke;
