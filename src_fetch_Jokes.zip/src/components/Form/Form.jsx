import styles from "./Form.module.scss";

const TaskForm = () => {
  return <h1>form</h1>;
};
